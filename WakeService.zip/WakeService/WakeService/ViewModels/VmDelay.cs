﻿namespace WakeService.ViewModels
{
    public class VmDelay
    {
        public bool IsDelayed { get; set; }
        public int DelayedByMinutes { get; set; }
    }
}